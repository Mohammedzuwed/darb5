list=[5,99,40,90,70]
s=max(list)
print(s)