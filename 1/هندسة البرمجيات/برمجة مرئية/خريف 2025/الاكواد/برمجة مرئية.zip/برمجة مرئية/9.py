user=[1,"hello",2.5]
user.append("blue")
print(user)