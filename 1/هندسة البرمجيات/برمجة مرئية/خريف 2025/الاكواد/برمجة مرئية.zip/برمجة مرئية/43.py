def even_or_add(n):
    if n%2==0:
        print("even")
    else:
        print("add")
n=int(input("Enter n= "))
even_or_add(n)