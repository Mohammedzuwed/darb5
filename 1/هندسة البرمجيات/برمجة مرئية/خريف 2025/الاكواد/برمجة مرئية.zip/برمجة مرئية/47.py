def letters(n):
    print(len(n))
n=input("Enter Word :")
letters(n)