while True:
    
    a=int(input("Enter Mark Range :"))
    if a==-1:
        print("Exiting...")
        break
    if  a<=100 and a>=90:
        print("Excellent")
    elif a<=89 and a>=75:
        print("Very Good")
    elif a<=74 and a>=60:
        print("Good")
    elif a<=59 and a>50:
        print("pass")
    elif a<=49 and a>=0:
        print("Fail")
    else:
     print("invalid mark")