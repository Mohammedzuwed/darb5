list=[55,44,2]
list.pop(2)
print(list)