adj=["red","big","testy"]
fruits=["apple","banana","cherry"]
for x in adj:
    for y in fruits:
        print(x,y)