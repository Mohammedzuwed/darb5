list=[1,55,4,2,11,8,70]
list.sort(reverse=True)
print(list)