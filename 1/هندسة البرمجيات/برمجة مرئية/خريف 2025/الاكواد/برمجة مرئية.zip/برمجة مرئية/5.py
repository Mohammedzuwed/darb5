user=[1,"hello",2.5]
print(user[0])