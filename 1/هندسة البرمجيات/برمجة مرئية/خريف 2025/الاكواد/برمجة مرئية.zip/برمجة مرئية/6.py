user=[1,22,45,70]
print(max(user))