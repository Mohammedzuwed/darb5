text="Ali$Sara,Omar"
print(text.split("$"))