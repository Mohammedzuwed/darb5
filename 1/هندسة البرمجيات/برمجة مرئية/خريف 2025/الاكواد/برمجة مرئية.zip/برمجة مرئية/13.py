list=[1,55,4,8,9,70]
list.sort()
print(list)