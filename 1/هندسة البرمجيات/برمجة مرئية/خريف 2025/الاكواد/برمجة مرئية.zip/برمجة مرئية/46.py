def cal(a,b,op):
    if op =="+":
        print(a+b)
    elif op =="-":
        print(a-b)
    elif op =="*":
        print(a*b)
    elif op=="/":
        print(a/b)
    else:
        print("invalid opration")
a=float(input("Enter a= " ))
b=float(input("Enter b= " ))
op=input("Enter op: ")
cal(a,b,op)