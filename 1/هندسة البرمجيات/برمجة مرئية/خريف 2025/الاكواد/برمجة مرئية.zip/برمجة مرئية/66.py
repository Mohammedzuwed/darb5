text="Ali 25"
n,age=text.split()
print(n)
print(age)