fruits=["apple","banana","cherry"]
for x in fruits:
    if x=="banana":
        print("found")
    else:
        print("not found")