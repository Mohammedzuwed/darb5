def fullname(fname , lname):
    print(fname + ' ' + lname)
f=input("Enter frist name")
l=input("Enter last name")
fullname(f,l)