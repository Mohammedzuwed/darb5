def find_max():
    x=int(input("Enter x = "))
    y=int(input("Enter y = "))
    z=int(input("Enter z = "))
    print("max is : ",max(x,y,z))
    
find_max()