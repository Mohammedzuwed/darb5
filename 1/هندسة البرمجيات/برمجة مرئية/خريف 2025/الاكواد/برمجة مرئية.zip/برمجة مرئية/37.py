def fahrenheit_to_celsius(fahrenheit):
    print( (fahrenheit-32)*5/9)
fahrenheit_to_celsius(float(input("Enter temp: ")))