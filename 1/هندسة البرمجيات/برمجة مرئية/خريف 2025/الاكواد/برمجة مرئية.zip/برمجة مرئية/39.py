def fullname(fname , lname):
    print(fname + " " + lname)
fullname(input("Enter frist name"),input("Enter last name"))