fruits=["apple","banana","cherry"]
for x in fruits:
    if x=="banana":
        continue
    else:
        print(x)