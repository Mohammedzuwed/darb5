x=0
for i in "loop":
    if i=="o":
        x+=1
print(x)