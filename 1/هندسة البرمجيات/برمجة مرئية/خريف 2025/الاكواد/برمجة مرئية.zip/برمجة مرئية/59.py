text="Ali Sara Omar"
print(text[0:3])