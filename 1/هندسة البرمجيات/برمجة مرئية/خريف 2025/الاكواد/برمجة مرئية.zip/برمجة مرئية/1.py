a=int(input("Enter minutes :"))
if a%2==0:
    print("Forgiven")
else:
    print("Late")
