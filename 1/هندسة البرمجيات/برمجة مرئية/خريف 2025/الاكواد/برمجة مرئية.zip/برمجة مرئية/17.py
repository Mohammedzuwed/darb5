list=[5,99,40,90,70]
list.sort()
print(list[-1])