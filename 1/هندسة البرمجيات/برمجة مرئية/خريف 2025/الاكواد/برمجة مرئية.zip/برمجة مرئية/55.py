def rectangles(a,b):
    area=a*b
    return area
for i in range(3):
    a=float(input("Enter width = "))
    b=float(input("Enter height = "))
    print(rectangles(a,b))