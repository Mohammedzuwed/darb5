t=["a12","b07","c03"]
r=["add d07","remove b07","add a15","remove c01"]
for i in r:
    ac,tag=i.split()
    if ac =="add":
        t.append(tag)
    elif ac=="remove" and tag in t:
        t.remove(tag)
t.sort()
print(t)