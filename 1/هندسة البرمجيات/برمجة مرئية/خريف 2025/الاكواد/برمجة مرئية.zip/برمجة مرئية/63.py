num=input("Enter Num: ")
x=num.split()
print(x)