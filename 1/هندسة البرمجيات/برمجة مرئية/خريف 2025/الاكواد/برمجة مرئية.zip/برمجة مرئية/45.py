def average_score(a,b,c):
     print((a+b+c)/3)
a=float(input("Enter a= "))
b=float(input("Enter b= "))
c=float(input("Enter c= "))
average_score(a,b,c)