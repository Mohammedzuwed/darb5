def fullname(fname , lname):
    print(fname + " " + lname)
fullname("Ali", "Black")