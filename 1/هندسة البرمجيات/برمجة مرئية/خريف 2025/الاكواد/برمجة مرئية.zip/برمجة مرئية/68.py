num=input("Enter Num: ")
nums=num.split()
nums=list(map(int,nums))
print(sum(nums))
