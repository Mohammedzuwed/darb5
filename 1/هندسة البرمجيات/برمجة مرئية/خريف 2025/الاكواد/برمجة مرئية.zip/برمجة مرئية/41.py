def find_max(x,y,z):
    print("max is : ",max(x,y,z))
x=int(input("Enter x = "))
y=int(input("Enter y = "))
z=int(input("Enter z = "))
find_max(x,y,z)
    
