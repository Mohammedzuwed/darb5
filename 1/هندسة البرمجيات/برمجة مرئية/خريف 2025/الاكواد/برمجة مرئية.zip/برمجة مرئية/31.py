x=int(input())
y=[]
for i in range(x):
    z=int(input())
    if z%2==0:
        y.append(z) 
print(y)
