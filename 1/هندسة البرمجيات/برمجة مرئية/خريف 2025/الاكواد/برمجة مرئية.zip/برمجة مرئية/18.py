n=int(input("Enter number students: "))
scores=[]
for i in range(n):
    x=int(input("Enter score of student: "))
    scores.append()
print(max(scores))