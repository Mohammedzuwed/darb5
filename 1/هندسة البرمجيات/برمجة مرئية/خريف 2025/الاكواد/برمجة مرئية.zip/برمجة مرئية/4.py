a = int(input("Enter temperature cold: "))
b = int(input("Enter temperature hot: "))
room_temp = 25
c = abs(a - room_temp)
d = abs(b - room_temp)
if c < d:
    print("cold")
elif d < c:
    print("hot")
else:
    print("cold and hot")