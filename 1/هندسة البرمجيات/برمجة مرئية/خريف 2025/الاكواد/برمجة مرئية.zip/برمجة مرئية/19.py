list=[55,44,2]
list.clear()
print(list)