t=[]
a=["re 5","re 3","re 5","ca 3","re 7"]
for i in a:
    ac,x=i.split()
    z=int(x)
    if ac =="re" and z not in t:
        t.append(z)
    elif ac =="ca" and z in t:
        t.remove(z)
print(t)
    