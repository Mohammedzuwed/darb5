text="Ali 25"
a=text.split()
n=a[0]
age=a[1]
print(n)
print(age)
