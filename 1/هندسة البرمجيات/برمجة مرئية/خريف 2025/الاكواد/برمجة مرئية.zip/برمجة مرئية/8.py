user=[1,"hello",2.5]
user.insert(2,"world")
print(user)