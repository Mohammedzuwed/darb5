answer=""
while answer.lower()!="yes":
    answer=input()
print("Great!")