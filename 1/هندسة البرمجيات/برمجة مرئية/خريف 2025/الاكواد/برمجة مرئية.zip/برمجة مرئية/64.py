num=input("Enter Num: ")
nums=num.split()
total=0
for i in nums:
    total+=int(i)
print(total)