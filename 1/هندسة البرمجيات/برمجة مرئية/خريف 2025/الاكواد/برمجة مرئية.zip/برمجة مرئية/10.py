user=[1,"hello",2.5]
user[0:2]=[55]
print(user)