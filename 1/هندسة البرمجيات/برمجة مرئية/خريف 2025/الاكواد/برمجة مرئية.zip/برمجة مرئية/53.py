def rectangles(a,b):
    area=a*b
    print(area)
for i in range(3):
    a=float(input("Enter width = "))
    b=float(input("Enter height = "))
    rectangles(a,b)