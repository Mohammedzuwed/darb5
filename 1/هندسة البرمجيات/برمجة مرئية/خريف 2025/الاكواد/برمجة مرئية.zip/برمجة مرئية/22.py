x=int(input())
list=[]
for i in range(x):
    z=int(input())
    list.append(z)
print(sum(list)) 