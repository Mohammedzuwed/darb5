def rectangles(a,b):
    a=float(input("Enter width = "))
    b=float(input("Enter height = "))
    area=a*b
    print(area)
rectangles()
rectangles()
rectangles()