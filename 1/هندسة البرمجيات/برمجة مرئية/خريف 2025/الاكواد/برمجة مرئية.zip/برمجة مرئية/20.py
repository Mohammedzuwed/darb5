list=[55,44,2]
list.remove(44)
print(list)