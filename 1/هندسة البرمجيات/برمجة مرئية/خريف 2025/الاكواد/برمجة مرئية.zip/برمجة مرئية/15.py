list=[1,55,4,2,11,8,70]
list2=list.copy()
print(list2)
