def fahrenheit_to_celsius(fahrenheit):
    print( (fahrenheit-32)*5/9)
fahrenheit_to_celsius(77)
fahrenheit_to_celsius(50)
fahrenheit_to_celsius(10)