#include<iostream>
using namespace std;
class Retangle{
    public:
    double length;
    double width;
    void calculateArea(){
        cout<<"Area: "<<length*width<<endl;
    }
};
int main() {
    Retangle rect1;
    rect1.length = 3.0;
    rect1.width = 2.0;
    rect1.calculateArea();
    return 0;
}