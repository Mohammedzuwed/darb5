#include<iostream>
#include<cmath>
using namespace std;
class rectangle{
    public:
    double a,b;
    rectangle(int x,int y){
        a=x,b=y;
      cout<<a+b<<endl;
    }
    rectangle(){
        a=9;
        b=8;
        cout<<a+b<<endl;        
    }
};
int main(){
    int x,y;
    cin>>x>>y;
    rectangle i;
    rectangle u(x,y);
}