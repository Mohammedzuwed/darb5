#include<iostream>
using namespace std;
class Rectangle{
    public:
    int length;
    int width;
    void calculateArea(){
        cout<<"Area: "<<length*width<<endl;
    }
};  
int main() {
    Rectangle rect1;
    cin>>rect1.length;
    cin>>rect1.width;
    rect1.calculateArea();
    return 0;
}
