#include<iostream>
using namespace std;
class Rectangle{
    public:
    double length;
    double width;
    void readData(){
        cout<<"Enter length of rectangle: ";
        cin>>length;
        cout<<"Enter width of rectangle: ";
        cin>>width;
    }
    void calculateArea(){
        cout<<"Area: "<<length*width<<endl;
    }
};
int main() {
    Rectangle rect1;
    rect1.readData();
    rect1.calculateArea();
    return 0;
}