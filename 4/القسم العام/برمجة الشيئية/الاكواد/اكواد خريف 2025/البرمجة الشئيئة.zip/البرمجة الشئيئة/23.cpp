#include<iostream>
using namespace std;
class r{
    public:
    int id;
    string name;
    r(){
        cout<<"ID: ";
        cin>>id;
        cout<<"Name: ";
        cin>>name;
    }
    void d(){
        cout<<"ID: "<<id<<endl;
        cout<<"Name: "<<name<<endl;
    }
    ~r(){
        cout<<"Destructor called for ID: "<<id<<endl;
    }
};
int main(){
    int x;
    cin>>x;
    r obj[x];
    for(int j=0;j<x;j++){
        obj[j].d();
    }
}