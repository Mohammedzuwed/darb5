#include <iostream>
using namespace std;
class Rectangle {
private:
    int length;
    int width;
public:
    void setDimensions() {
       cin >> length >> width;
    }
    void displayArea() {
        cout << "Area: " << length * width << endl;
    }
};
int main() {
    Rectangle rect1;
    rect1.setDimensions();
    rect1.displayArea();
    return 0;
}
