#include<iostream>
#include<cmath>
using namespace std;
class rectangle{
    public:
    double a,b,c,s;
    rectangle(int x,int y,int z){
        a=x,b=y,c=z;
      s=(a+b+c)/2;
      cout<<sqrt((s*(s-a)*(s-b)*(s-c)))<<endl;
    }
    rectangle(){
        a=9;
        b=8;
        c=10;
        s=(a+b+c)/2;
      cout<<sqrt((s*(s-a)*(s-b)*(s-c)))<<endl;
        
    }
};
int main(){
    rectangle i;
    rectangle j(4,9,9);
}