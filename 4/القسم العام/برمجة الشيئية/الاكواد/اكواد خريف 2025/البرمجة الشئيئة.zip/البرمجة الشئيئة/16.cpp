#include<iostream>
#include<cmath>
using namespace std;
class rectangle{
    public:
    double a,b,c,s;
    rectangle(int x,int y,int z){
        a=x,b=y,c=z;
      s=(a+b+c)/2;
      cout<<sqrt((s*(s-a)*(s-b)*(s-c)))<<endl;
    }
};
int main(){
    rectangle i(4,5,6);
}