#include<iostream>
#include<cmath>
using namespace std;
class rectangle{
    public:
    double a,b;
    rectangle(){
        a=9;
        b=8;
        cout<<a+b<<endl;        
    }
};
int main(){
    rectangle i;
}