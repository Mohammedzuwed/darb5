#include<iostream>
using namespace std;
class Shape {
public:
    virtual void draw() = 0;
    virtual void area() = 0;
};//كلاس اب مجرد ما فيهوش تنفيذ للدوال الافتراضية(يعني منقدرش ننشاء كائن من كلاس الاب من النوع abstract
class Circle : public Shape {
public: 
void draw() override {
        cout << "Drawing a Circle" << endl;
    }
void area() override {
        cout << "Area of Circle: 3.14*r*r" << endl;
    }//ضروري نعرف كل الدوال الموجودة في كلاس الاب ومكتوب جنبها virtual = 0
    //ضروري نعرف كل الدوال الافتراضية في الاب نعرفهم في كلاس الابن بكل تفاصيلهم لو مكتبناش وحدة منهم حيطلع خطا ولا يمكن انشاء كائن من هذا الكلاس (كلاس الابن)
};
int main() {
    Circle c;
    c.draw();
    c.area();
    return 0;
}