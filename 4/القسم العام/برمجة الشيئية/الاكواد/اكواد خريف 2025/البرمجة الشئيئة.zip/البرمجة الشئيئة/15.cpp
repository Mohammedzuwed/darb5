#include<iostream>
#include<cmath>
using namespace std;
class rectangle{
    public:
    double a,b,c,s;
    rectangle(){
        a=9;
        b=8;
        c=10;
        s=(a+b+c)/2;
      cout<<sqrt((s*(s-a)*(s-b)*(s-c)))<<endl;
        
    }
};
int main(){
    rectangle i;
}