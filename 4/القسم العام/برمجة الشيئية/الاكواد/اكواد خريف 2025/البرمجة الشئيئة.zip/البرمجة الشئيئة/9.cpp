#include<iostream>
using namespace std;
class rectangle{
    public:
    double length;
    double width;
    void calculateArea(){
        cout<<"Area = "<<length*width;
    }
};
int main(){
    rectangle rect1;
    cout<<"Enter length: ";
    cin>>rect1.length;
    cout<<"Enter width: ";
    cin>>rect1.width;
    rect1.calculateArea();
}