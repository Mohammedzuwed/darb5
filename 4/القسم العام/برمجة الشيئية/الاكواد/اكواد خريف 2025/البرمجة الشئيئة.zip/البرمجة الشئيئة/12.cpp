#include<iostream>
using namespace std;
class rectangle{
    private:
    int x,y,z;
    public:
    void readData(){
        cin>>x;
        cin>>y;
        cin>>z;
    }
    void calculate(){
        if((x>y)&&(x>z))
        cout<<x;
        else if((y>x)&&(y>z))
        cout<<y;
        else if((z>x)&&(z>y))
        cout<<z;
    }
};
int main(){
    rectangle t;
     t.readData();
    t.calculate();
}