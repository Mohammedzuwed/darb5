#include <iostream>
using namespace std;
class Shape {
    public:
    virtual void calculateArea() = 0;
    virtual void calculatePerimeter() = 0;
};
class Rectangle : public Shape {
    public:
    float length;
    float width;
    Rectangle(float l, float w): length(l), width(w) {
    }
    void calculateArea() override {
        cout << "Area of Rectangle: " << length * width << endl;
    }
    void calculatePerimeter() override {
        cout << "Perimeter of Rectangle: " << 2 * (length + width) << endl;
    }
};
class Circle : public Shape {
    public:
    float radius;
    Circle(float r): radius(r) {
    }
    void calculateArea() override {
        cout << "Area of Circle: " << 3.14 * radius * radius << endl;
    }
    void calculatePerimeter() override {
        cout << "Perimeter of Circle: " << 2 * 3.14 * radius << endl;
    }
};
int main() {
    Rectangle rect(5.0, 3.0);
    rect.calculateArea();
    rect.calculatePerimeter();
    Circle circ(4.0);
    circ.calculateArea();
    circ.calculatePerimeter();
    return 0;
}
