#include<iostream>
using namespace std;
class rectangle{
    private:
    int x,y,z;
    public:
    void readData(int a,int b,int c){
        x=a;
        y=b;
        z=c;
    }
    void calculate(){
        if((x>y)&&(x>z))
        cout<<x;
        else if((y>x)&&(y>z))
        cout<<y;
        else if((z>x)&&(z>y))
        cout<<z;
    }
};
int main(){
    rectangle t;
    int a,b,c;
    cin>>a;
     cin>>b;
     cin>>c;
     t.readData(a,b,c);
    t.calculate();
}