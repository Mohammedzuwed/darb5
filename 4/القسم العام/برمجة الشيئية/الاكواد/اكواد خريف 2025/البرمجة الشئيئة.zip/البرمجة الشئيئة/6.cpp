#include <iostream>
#include <cmath>
using namespace std;
class Rectangle {
private:
int a,b,c,s;
public:
    void calculateArea(int a1,int b1,int c1){
        a=a1;
        b=b1;
        c=c1;
        s=(a+b+c)/2;
        cout<<"A= "<<sq(s*(s-a)*(s-b)*(s-c))<<endl;
    }
};
int main(){
    Rectangle rect1;
    int a1,b1,c1;
    cin>>a1>>b1>>c1;
    rect1.calculateArea(a1,b1,c1);
    return 0;
}