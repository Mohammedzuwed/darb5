#include<iostream>
using namespace std;
class rectangle{
    public:
    int length;
    int width;
    void calculateArea(){
        cout<<"Area = "<<length*width<<endl;
    
    }
};
int main(){
    rectangle rect1;
    rect1.length=3.0;
    rect1.width=2.0;
    rect1.calculateArea();
}