#include<iostream>
#include<string>
using namespace std;
class Employee {
public:
    string name;
    int id;
    Employee(string n, int i): name(n), id(i) {
}
virtual void calculateSalary() = 0;
virtual void displayInfo() = 0; 
};
class premiumEmployee : public Employee {
public:
float fixedSalary;
float bonus;
premiumEmployee(string n, int i, float fs, float b): Employee(n, i), fixedSalary(fs), bonus(b) {
}
void calculateSalary() override {
   cout<<"calculated Salary for: "<<name<<"Fixed Base + Bonus"<<fixedSalary + bonus<<endl;
}
void displayInfo() override {
    cout << "Employee Name: " << name << endl;
    cout << "Employee ID: " << id << endl;
}};
class ContractEmployee : public Employee {
public:
    float hourlyRate;
    int hoursWorked;
    ContractEmployee(string n, int i, float hr, int hw): Employee(n, i), hourlyRate(hr), hoursWorked(hw) {
    }
    void calculateSalary() override {
        cout << "calculated Salary for: " << name << " Hourly Rate * Hours Worked " << hourlyRate * hoursWorked << endl;
    }
    void displayInfo() override {
        cout << "Employee Name: " << name << endl;
        cout << "Employee ID: " << id << endl;
    }};
int main() {
    premiumEmployee pe("Alice", 101, 5000.0, 1500.0);
    pe.displayInfo();
    pe.calculateSalary();
    ContractEmployee ce("Bob", 102, 50.0, 160);
    ce.displayInfo();
    ce.calculateSalary();
    return 0;
}
