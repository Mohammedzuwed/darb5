#include<iostream>
using namespace std;
class Area{
    public:
    double r;
    void calculateArea(){
        cout<<"Enter r = ";
        cin>>r;
        double area=3.14*r*r;
        cout<<"Area : "<<area<<endl;
    }
};
int main() {
    Area c1;
    c1.calculateArea();
    return 0;
}