#include <iostream>
using namespace std;
class Rectangle {
public:
    int length;
    int width;
    void calculateArea(int l, int w) {
        length = l;
        width = w;
    }
    void displayArea() {
        cout << "Area: " << length * width << endl;
    }
};
int main() {
    Rectangle rect1;
    Rectangle rect2;
    int l, w;
    cout << "Enter length: ";
    cin >> l;
    cout << "Enter width: ";
    cin >> w;
    rect1.calculateArea(l, w);
    rect1.displayArea();
    return 0;
}
