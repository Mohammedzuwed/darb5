#include<iostream>
using namespace std;
class rectangle{
    public:
    double length;
    double width;
    void readData(){
        cout<<"Enter length: ";
        cin>>length;
        cout<<"Enter width: ";
        cin>>width;
    }
    void calculateArea(){
        cout<<"Area = "<<length*width;
    }
};
int main(){
    rectangle rect1;
    rect1.readData();
    rect1.calculateArea();
}