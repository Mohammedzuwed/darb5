#include <iostream>
#include <string>
using namespace std;
class Course {
public:
    string title;          
    int noStd;             
    string instructorName; 
 Course(string a, int b, string c) {
    title = a;
    noStd = b;
    instructorName = c;
}
void addStudent() {
    noStd++;         
}
void removeStudent() {
    if (noStd > 0)    
        noStd--;      
    }
virtual void displayCourseInfo() {
        cout << "اسم الدورة: " << title << endl;         
        cout << "عدد الطلبة: " << noStd << endl;          
        cout << "اسم المدرب: " << instructorName << endl; 
    }
};
class OnlineCourse : public Course {
public:
    string platform;      
    OnlineCourse(string a, int b, string c, string d): Course(a, b, c) {
        platform = d;      
    }
    void displayCourseInfo() override {
        cout << "اسم الدورة: " << title << endl;         
        cout << "عدد الطلبة: " << noStd << endl;          
        cout << "اسم المدرب: " << instructorName << endl; 
        cout << "منصة العرض: " << platform << endl;      
    }
};
int main() {
    Course Ccpp("أساسيات C++", 10, "أحمد");              
    OnlineCourse Conline("أساسيات C++", 5, "فاطمة", "Zoom"); 
    Ccpp.addStudent();                                  
    Ccpp.addStudent();                                  
    Conline.addStudent();                               
    Conline.addStudent();                                
    Conline.removeStudent();                           
    Ccpp.displayCourseInfo();                         
    Conline.displayCourseInfo();    
    return 0;                                          
}