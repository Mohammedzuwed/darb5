#include<iostream>
using namespace std;
class r{
   public:
   int x;
   int m=0,h=0;
   void time(){
      while(x>=60){
         x=x-60;
         m++;
      }
      while(m>=60){
         m=m-60;
         h++;
      }
      cout<<"Time is: "<<h<<":"<<m<<":"<<x<<endl;
   }
};
int main(){
   r t1;
   cout<<"Enter time in seconds: ";
   cin>>t1.x;
   t1.time();
   return 0;
}