#include<iostream>
using namespace std;
class rectangle{
    private:
    int x;
    public:
    float y,z;
    void readData(){
        cin>>x;
    }
    void calculate_h(){
     z=(x/3600);
     cout<<z<<endl;
    }
    void calculate_m(){
        y=(x/60);
        cout<<y;
    }
};
int main(){
    rectangle t;
    rectangle z;
    z.readData();
    z.calculate_h();
    t.readData();
    t.calculate_m();
}