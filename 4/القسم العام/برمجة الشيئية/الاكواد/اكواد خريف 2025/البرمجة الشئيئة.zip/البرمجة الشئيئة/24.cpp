#include<iostream>
using namespace std;
class r{
    public:
    char x[30];
    float y;
    void set(){
        cin>>x>>y;
    }
    void print(){
        cout<<x<<" "<<y<<" ";
    }
};
int main(){
    r z[5];
    for(int i=0;i<5;i++)
    z[i].set();
    for(int i=0;i<5;i++)
    z[i].print();
}