#include<iostream>
#include<cmath>
using namespace std;
class rectangle{
    public:
    double a,b;
    rectangle(int x,int y){
        a=x,b=y;
      cout<<a+b<<endl;
    }

};
int main(){
    rectangle i(9,8);
}