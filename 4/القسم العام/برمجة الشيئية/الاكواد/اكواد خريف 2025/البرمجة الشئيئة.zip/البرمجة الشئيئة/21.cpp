#include<iostream>
using namespace std;
class r{
    public:
    int x; float y; char z;
    r(int a){
        x=a;
        cout<<"int"<<endl;
    }
    r(double b){
        y=b;
        cout<<"double"<<endl;
    }
    r(char c){
        z=c;
        cout<<"char"<<endl;
    }
    ~r(){
        cout<<"DElead";
    }
};
int main(){
    r t(8.8);
    r s(5);
    r i('d');
}

